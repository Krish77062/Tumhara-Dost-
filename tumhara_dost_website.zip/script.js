
function showMessage() {
    const message = document.getElementById("message");
    message.textContent = "Tumhara Dost hamesha tumhare saath hai ❤️🔥";
}
